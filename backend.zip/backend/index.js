const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const app = express();
const port = 8000;

app.use(bodyParser.json());
const dbConfig = {
         host: 'localhost',
         user: 'root',
         password: 'HARSH',
         database: 'node-database',
       };
       
       const connection = mysql.createConnection(dbConfig);

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to database');
});

app.post('/register', (req, res) => {
         const { name, email, password } = req.body;
       
        // const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
         connection.query(sql, [name, email, password], (err, result) => {
           if (err) {
             console.error('Error executing SQL query:', err);
             res.status(500).json({ error: 'An error occurred' });
             return;
           }
           console.log('User registered:', result);
           res.status(200).json({ message: 'User registered successfully' });
         });
       });




app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
